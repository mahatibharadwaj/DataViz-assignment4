CS/DS 732 Data Visualization
Assignment - 4
Roll Number - IMT2014022, IMT2014031
Date of Submission - 26 November, 2017

The screenshot images of the output are contained in the folder titled 'images'.
The data files(.csv, .json) are contained in the folder titled 'data'.
The css files(.css) are contained in the folder titled 'css'.
The java script files(.js) are contained in the folder titled 'js'.

To run the programs, just open the HTML file(index.html) using the web-browser.

References:
1.  https://d3js.org/
2.  https://en.wikipedia.org/wiki/Google_Fusion_Tables
3.  https://www.crunchbase.com/
	
